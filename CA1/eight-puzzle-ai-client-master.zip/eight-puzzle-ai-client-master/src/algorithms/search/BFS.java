package algorithms.search;

import algorithms.Algorithm;

public class BFS implements Algorithm {
    @Override
    public String makeMove(String[][] grid) {
        return null;
    }
}
