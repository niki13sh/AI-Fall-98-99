package algorithms.search;

import algorithms.Algorithm;

public class AStar implements Algorithm {
    @Override
    public String makeMove(String[][] grid) {
        return null;
    }
}
